import React,{Component} from "react";

class User extends Component{
    render(){
return <h1>Hello</h1>
    }
}
export class Otheruser extends Component{
render(){
    return <h1>Otheruser</h1>
}
}
export default User;